export const REPORTS = [
  { code: "ACTV", name: "Recent Activity Report" },
  { code: "PEND", name: "Pending Requests Report" },
  { code: "USRS", name: "Active Users Report" },
  { code: "AUDT", name: "Audit Trail Report" },
];
