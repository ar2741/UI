import React, { useState } from "react";
import "./Admindashboardsettings.css";
import logo from "../../Assests/sclogoshiva.png";
import { Link } from "react-router-dom";

function Admindashboardsettings() {
    const [formData, setFormData] = useState({
        firstName: "Admin",
        lastName: "User",
        email: "admin@standardchartered.com",
        currentPassword: "",
        newPassword: "",
        confirmPassword: ""
    });

    const [isEditing, setIsEditing] = useState(false);

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({
            ...prev,
            [name]: value
        }));
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        if (formData.newPassword && formData.newPassword !== formData.confirmPassword) {
            alert("New passwords do not match!");
            return;
        }
        // Here you would typically make an API call to update the settings
        alert("Settings updated successfully!");
        setIsEditing(false);
    };

    const handleCancel = () => {
        setFormData({
            firstName: "Admin",
            lastName: "User",
            email: "admin@standardchartered.com",
            currentPassword: "",
            newPassword: "",
            confirmPassword: ""
        });
        setIsEditing(false);
    };

    return (
        <div className="settings-container">
            {/* Top Bar */}
            <header className="top-bar">
                <div className="top-bar-left">
                    <h2>Settings</h2>
                </div>
                <div className="top-bar-right">
                    <div className="profile-section">
                        <div className="profile-pic">
                            <img src="https://via.placeholder.com/40" alt="Profile" />
                        </div>
                        <span className="username">Admin User</span>
                        <button className="logout-btn">Logout</button>
                    </div>
                </div>
            </header>

            <div className="content-wrapper">
                {/* Sidebar */}
                <aside className="sidebar">
                    <div className="logo-section">
                        <img src={logo} alt="Standard Chartered" className="logo" />
                    </div>
                    <div className="menu-section">
                        <ul>
                             <li> <Link to="/AdminDashboard" className="menu-link">Dashboard</Link></li>
                            <li><Link to="/AdminUser" className="menu-link">User Management</Link></li>
                          
                            <li><Link to="/ReportAccess" className="menu-link">Report Access</Link></li>
                            <li><Link to="/Admindashboardsettings" className="menu-link">Settings</Link></li>
                            <li><Link to="/Adminaccount" className="menu-link">Account</Link></li>
                            <li><Link to="/Adminhelp" className="menu-link">Help</Link></li>
                        </ul>
                    </div>
                </aside>

                {/* Main Content */}
                <main className="main-content">
                    <div className="settings-card">
                        <div className="card-header">
                            <h2>Profile Settings</h2>
                            <button
                                className={`edit-btn ${isEditing ? 'cancel-btn' : ''}`}
                                onClick={isEditing ? handleCancel : () => setIsEditing(true)}
                            >
                                {isEditing ? 'Cancel' : 'Edit Profile'}
                            </button>
                        </div>

                        <form className="settings-form" onSubmit={handleSubmit}>
                            <div className="form-section">
                                <h3>Personal Information</h3>
                                <div className="form-row">
                                    <div className="form-group">
                                        <label htmlFor="firstName">First Name</label>
                                        <input
                                            type="text"
                                            id="firstName"
                                            name="firstName"
                                            value={formData.firstName}
                                            onChange={handleInputChange}
                                            disabled={!isEditing}
                                            className="form-control"
                                        />
                                    </div>
                                    <div className="form-group">
                                        <label htmlFor="lastName">Last Name</label>
                                        <input
                                            type="text"
                                            id="lastName"
                                            name="lastName"
                                            value={formData.lastName}
                                            onChange={handleInputChange}
                                            disabled={!isEditing}
                                            className="form-control"
                                        />
                                    </div>
                                </div>
                                <div className="form-group">
                                    <label htmlFor="email">Email Address</label>
                                    <input
                                        type="email"
                                        id="email"
                                        name="email"
                                        value={formData.email}
                                        onChange={handleInputChange}
                                        disabled={!isEditing}
                                        className="form-control"
                                    />
                                </div>
                            </div>

                            {isEditing && (
                                <div className="form-section">
                                    <h3>Change Password</h3>
                                    <div className="form-group">
                                        <label htmlFor="currentPassword">Current Password</label>
                                        <input
                                            type="password"
                                            id="currentPassword"
                                            name="currentPassword"
                                            value={formData.currentPassword}
                                            onChange={handleInputChange}
                                            className="form-control"
                                            placeholder="Enter current password"
                                        />
                                    </div>
                                    <div className="form-row">
                                        <div className="form-group">
                                            <label htmlFor="newPassword">New Password</label>
                                            <input
                                                type="password"
                                                id="newPassword"
                                                name="newPassword"
                                                value={formData.newPassword}
                                                onChange={handleInputChange}
                                                className="form-control"
                                                placeholder="Enter new password"
                                            />
                                        </div>
                                        <div className="form-group">
                                            <label htmlFor="confirmPassword">Confirm New Password</label>
                                            <input
                                                type="password"
                                                id="confirmPassword"
                                                name="confirmPassword"
                                                value={formData.confirmPassword}
                                                onChange={handleInputChange}
                                                className="form-control"
                                                placeholder="Confirm new password"
                                            />
                                        </div>
                                    </div>
                                </div>
                            )}

                            {isEditing && (
                                <div className="form-actions">
                                    <button type="submit" className="save-btn">
                                        Save Changes
                                    </button>
                                </div>
                            )}
                        </form>
                    </div>
                </main>
            </div>
        </div>
    );
}

export default Admindashboardsettings;